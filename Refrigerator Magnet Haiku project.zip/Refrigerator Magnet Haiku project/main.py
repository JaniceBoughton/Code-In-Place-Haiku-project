from graphics import Canvas
import random
#first we create a library of words and phrases that work together randomly, add up to 5-7-5 syllables and are haiku-ish
FIRST_LINE_FIRST = ["waiting for ", "ripples on ", "thinking on ", "giving you ", "only now ", "but surely ", "talk of "]
FIRST_LINE_NEXT = ["plum wine", "beach sand", "small stones", "lost things", "each breath", "snowdrops", "each word", "dry earth", "small gifts "]
SECOND_LINE_FIRST = ["against ", "between ", "after ", "beside ", "around ", "after ", "over "]
SECOND_LINE_SECOND = ["yellow ", "amber ", "yearned for ", "precious ", "dusty ", "lonely ", "endless ", "wind blown "]
SECOND_LINE_THIRD = ["daffodils", "apricots", "goldenrods", "wanderings",  "robin songs", "doorsteps ", "book pages", "fields of grass"]
THIRD_LINE_FIRST = ["the ", "my ", "now ", "missed ", "first ", "two ", "three "]
THIRD_LINE_SECOND = ["autumn ", "winter ", "summer ", "snowy ", "sun-touched ", "snow white ", "spring-touched "]
THIRD_LINE_THIRD = ["mountains", "bird songs", "roses", "snowflakes", "cookies", "grasses", "rainclouds", "daydreams"]
FIRST_LINE_FIRST_PYTHON = ["mischievous ", "curious ", "envious ", "vigilant ", "tentative ", "sensitive ", "ravenous ", "underfed ", "a wasteland "]
FIRST_LINE_NEXT_PYTHON = ["of course", "for sure", "perhaps", "in fact", "indeed", "I think", "clearly", "surely", "it seems"]
SECOND_LINE_FIRST_PYTHON = ["before ", "after ", "until ", "at last ", "but now "]
SECOND_LINE_SECOND_PYTHON = ["spotting ", "finding ", "seeking ", "sighting ", "tracking ", "sighting "]
SECOND_LINE_THIRD_PYTHON = ["winter ", "summer ", "autumn ", "rain soaked ", "frost chilled ", "spring touched "]
SECOND_LINE_FOURTH_PYTHON = ["prey", "birds", "rats", "mice", "fowl", "pets"]
THIRD_LINE_SECOND_PYTHON = ["strolls ", "does ", "sees ", "scouts ", "prowls ", "tastes ", "in "]
THIRD_LINE_THIRD_PYTHON = ["Boston", "New York", "Stanford", "Tokyo", "London", "Paris"]
#then we randomize them to create first, second and third lines
def get_first_line():
    first_line_one = random.choice(FIRST_LINE_FIRST)
    first_line_two = random.choice(FIRST_LINE_NEXT)
    first_line = first_line_one + first_line_two
    return first_line

def get_second_line():
    second_line_one = random.choice(SECOND_LINE_FIRST)
    second_line_two = random.choice(SECOND_LINE_SECOND)
    second_line_three = random.choice(SECOND_LINE_THIRD)
    second_line = second_line_one + second_line_two + second_line_three
    return second_line
    
def get_third_line():    
    third_line_one = random.choice(THIRD_LINE_FIRST)
    third_line_two = random.choice(THIRD_LINE_SECOND)
    third_line_three = random.choice(THIRD_LINE_THIRD)
    third_line = third_line_one + third_line_two + third_line_three
    return third_line

# then an alternate set of lines for python haiku.
def get_first_line_python():
    first_line_one_python = random.choice(FIRST_LINE_FIRST_PYTHON)
    first_line_two_python = random.choice(FIRST_LINE_NEXT_PYTHON)
    first_line_python = first_line_one_python + first_line_two_python
    return first_line_python

def get_second_line_python():
    second_line_one_python = random.choice(SECOND_LINE_FIRST_PYTHON)
    second_line_two_python = random.choice(SECOND_LINE_SECOND_PYTHON)
    second_line_three_python = random.choice(SECOND_LINE_THIRD_PYTHON)
    second_line_four_python = random.choice(SECOND_LINE_FOURTH_PYTHON)
    second_line_python = second_line_one_python + second_line_two_python + second_line_three_python + second_line_four_python
    return second_line_python

def get_third_line_python():
    third_line_two_python = random.choice(THIRD_LINE_SECOND_PYTHON)
    third_line_three_python = random.choice(THIRD_LINE_THIRD_PYTHON)
    third_line_python = "python " + third_line_two_python + third_line_three_python
    return third_line_python
    
CANVAS_WIDTH = 400
CANVAS_HEIGHT = 400
# now a little haiku education and a random haiku or two.
def main():
    #this is the first one, which will get printed on the fridge. This saves it as a variable for printing, but allows us to write further haiku.
    first_line = get_first_line()
    second_line = get_second_line()
    third_line = get_third_line()
    
    #start with the introduction: learn to haiku

    intro_to_haiku = "Haiku is a short form poem of Japanese origin." + '\n' + "Haiku was once an introduction to a longer linked poem and in the late 19th century" + '\n' + "was called haiku to denote a specific poem form." + '\n' + "There is no rhyme or meter, but haiku traditionally is made up of 17 Japanese syllables." + '\n' + "Haiku in English are 3 line poems of 5, 7 and 5 syllables each." + '\n' + "Traditionally haiku contained a word that connected it to a season and related closely to nature." + '\n' + "Matsuo Basho was a poet who mastered this form, before it had a separate name." + '\n' + "His poems still feel fresh and surprising," + '\n' + "though he lived in the 1600's. Here is one of his:" + '\n'
    basho_haiku = "the voice of reeds" + '\n' + "sounds like the autumn wind" + '\n' + "from another mouth" + '\n'
    intro_to_rm_haiku = "This program's haiku is the sort of thing we could produce with word magnets on a refrigerator," + '\n' + "but even more random." + '\n' + "If, by chance, they are profound, that is because humans" + '\n' + "have a tremendous capacity to create meaning." + '\n' + "Human brains are amazing!" + '\n' + "So here you go:" + '\n'
    introduction = intro_to_haiku + '\n' + basho_haiku +'\n' + intro_to_rm_haiku + '\n'
    print(introduction)
    # now print the first random haiku.
    print(first_line + '\n'+ second_line + '\n' + third_line)
    print()
    # keep giving them haiku until they stop saying yes
    while (input("Would you like another haiku? Type 'yes' if you would. ") == "yes"):
        print('\n' + get_first_line() + '\n'+ get_second_line() + '\n' + get_third_line() + '\n')
        print()
    print()
    # then give them a haiku about python, whether they want it or not, continue as long as they say yes ;)
    if input("Would you like a haiku about python now? ") == "yes":
        print()
        print(get_first_line_python() + '\n'+ get_second_line_python() + '\n' + get_third_line_python() + '\n')
        
    else:
        print("I'm just going to assume you meant yes." + '\n')
        print(get_first_line_python() + '\n'+ get_second_line_python() + '\n' + get_third_line_python() +'\n')
    
    while (input("Would you like another haiku about python? Type 'yes' if you would. ") == "yes"):
        print('\n' + get_first_line_python() + '\n'+ get_second_line_python() + '\n' + get_third_line_python() + '\n' )
    print()
    # all good things must come to an end.
    print("That's great. I'm going to put that first one on the refrigerator. Thanks for participating!")
    
# now build a refrigerator and add some refrigerator magnets.
    canvas = Canvas(CANVAS_WIDTH, CANVAS_HEIGHT)
    canvas.create_rectangle(100, 100, 300, 350, color = "cyan")
    canvas.create_rectangle(100, 10, 300, 90, color = "cyan" )
    canvas.create_rectangle(110, 20, 120, 80)
    canvas.create_rectangle(110, 110, 120, 180)

    canvas.create_text(130, 130, text = first_line, font = "courier", font_size = 8)
    canvas.create_text(130, 140, text = second_line, font = "courier", font_size = 8)
    canvas.create_text(130, 150, text = third_line, font = "courier", font_size = 8)
    

    
if __name__ == '__main__':
    main()